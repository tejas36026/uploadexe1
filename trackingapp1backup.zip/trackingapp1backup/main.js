const { app,remote, ipcRenderer , BrowserWindow, ipcMain, globalShortcut, screen, clipboard, Notification, dialog } = require('electron');
const nlp = require('compromise'); // <<< ADD THIS LINE


const { autoUpdater } = require('electron-updater');

const path = require('path');
const fs = require('fs');
const activeWin = require('active-win');
const { GlobalKeyboardListener } = require('node-global-key-listener');

const log = require('electron-log');
log.transports.file.resolvePath = () => path.join(app.getPath('userData'), 'logs/main.log');
log.info('App starting...');

autoUpdater.logger = log; // Tell auto-updater to use our logger
autoUpdater.autoDownload = false; // IMPORTANT: We will trigger download manually
autoUpdater.autoInstallOnAppQuit = true;
function sendUpdateMessage(message) {
    log.info(message); // Always log the message
    if (controlWindow && !controlWindow.isDestroyed()) {
      // This is the correct way to talk to a window
      controlWindow.webContents.send('update-message', message);
    }
  }

  
  async function anonymizeText(originalText) {
    if (!originalText || typeof originalText !== 'string') {
        return '';
    }

    // This map tracks entities we've already assigned a placeholder to,
    // ensuring "John Doe" is always replaced with "person 1" in the same paste.
    const entityMap = new Map();
    let personCounter = 1;
    let companyCounter = 1;
    let locationCounter = 1;

    let processedText = originalText;
    const doc = nlp(originalText);

    // Find and map people's names
    doc.people().out('array').forEach(name => {
        if (!entityMap.has(name)) {
            entityMap.set(name, `person ${personCounter++}`);
        }
    });

    // Find and map organizations/companies
    doc.organizations().out('array').forEach(company => {
        if (!entityMap.has(company)) {
            entityMap.set(company, `company ${companyCounter++}`);
        }
    });
    
    // Find and map locations/places
    doc.places().out('array').forEach(place => {
         if (!entityMap.has(place)) {
            entityMap.set(place, `location ${locationCounter++}`);
        }
    });

    // To prevent replacement errors (e.g., replacing "John" before "John Smith"),
    // we sort the found names by length, from longest to shortest.
    const sortedEntities = Array.from(entityMap.keys()).sort((a, b) => b.length - a.length);

    for (const entity of sortedEntities) {
        const placeholder = entityMap.get(entity);
        // Escape special regex characters in the entity name before creating the RegExp
        const escapedEntity = entity.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        // Replace all occurrences of the entity in the text
        processedText = processedText.replace(new RegExp(escapedEntity, 'g'), placeholder);
    }

    return processedText;
}


let sessionCounter = 1;
const SESSION_COUNTER_FILE = path.join(app.getPath('userData'), 'session_counter.json');

let currentSessionActivities = []; 
let mainWindow;
let controlWindow;
let isTracking = false;
let isInvisible = true;
let trackingData = [];
let sessionID = null; // <<< NEW: To track the current session
let sessionData = [];
let startTime = null;
let keyListener;

let filterApps = false; // Flag to enable app-based filtering
let filterWindowTitle = false; // Flag to enable window title-based filtering

const DATA_DIR = path.join(__dirname, 'data');

// Include/Exclude lists
let includeList = [];
let excludeList = [];

try {
    if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
    }
} catch (error) {
    console.error('Error creating data directory:', error);
}

ipcMain.handle('get-app-version', () => {
    return app.getVersion();
});
  
const SESSIONS_DIR = path.join(app.getPath('userData'), 'sessions');
try {
    if (!fs.existsSync(SESSIONS_DIR)) {
        fs.mkdirSync(SESSIONS_DIR, { recursive: true });
    }
} catch (error) {
    console.error('Error creating sessions directory:', error);
}


function loadFilterLists() {
    try {
        // Look for filter files in the root directory (where your main.js is)
        const filterFilePath = path.join(__dirname, 'include.txt');
        const excludeFilePath = path.join(__dirname, 'exclude.txt');
        const configFilePath = path.join(__dirname, 'filter_config.json');

        console.log('Looking for filter files at:');
        console.log('  include.txt:', filterFilePath);
        console.log('  exclude.txt:', excludeFilePath);
        console.log('  config:', configFilePath);

        // Create filter files if they don't exist
        if (!fs.existsSync(filterFilePath)) {
            fs.writeFileSync(filterFilePath, '# Add keywords here (one per line) to track ONLY apps/windows containing them.\n# Examples: word, .docx, docs, plagiarismcheck.org, turnitin\nword\n.docx\ndocs\nplagiarismcheck.org\nturnitin\n');
            console.log('Created include.txt with default content');
        }
        if (!fs.existsSync(excludeFilePath)) {
            fs.writeFileSync(excludeFilePath, '# Add keywords here (one per line) to IGNORE any app/window containing them.\n# Examples: chrome, firefox, notepad\n');
            console.log('Created exclude.txt with default content');
        }
        // Create config file if it doesn't exist
        if (!fs.existsSync(configFilePath)) {
            const defaultConfig = {
                filterApps: true,
                filterWindowTitle: true
            };
            fs.writeFileSync(configFilePath, JSON.stringify(defaultConfig, null, 2));
            console.log('Created filter_config.json with default settings');
        }
        // Load configuration flags
        const config = JSON.parse(fs.readFileSync(configFilePath, 'utf-8'));
        filterApps = config.filterApps || false;
        filterWindowTitle = config.filterWindowTitle || false;
        // Load include list
        const includeContent = fs.readFileSync(filterFilePath, 'utf-8');
        includeList = includeContent
            .split('\n')
            .map(line => line.trim())
            .filter(line => line && !line.startsWith('#'))
            .map(keyword => keyword.toLowerCase());

        // Load exclude list
        const excludeContent = fs.readFileSync(excludeFilePath, 'utf-8');
        excludeList = excludeContent
            .split('\n')
            .map(line => line.trim())
            .filter(line => line && !line.startsWith('#'))
            .map(keyword => keyword.toLowerCase());

        console.log('✅ Filter configuration loaded:');
        console.log(`   -> Filter Apps: ${filterApps}`);
        console.log(`   -> Filter Window Titles: ${filterWindowTitle}`);
        console.log(`   -> Include List (${includeList.length}):`, includeList);
        console.log(`   -> Exclude List (${excludeList.length}):`, excludeList);

        // Show what was actually read from files
        if (includeList.length === 0) {
            console.log('⚠️  Include list is empty. Check your include.txt file content.');
            console.log('   Current include.txt content:');
            console.log('   ', fs.readFileSync(filterFilePath, 'utf-8').replace(/\n/g, '\\n'));
        }

    } catch (error) {
        console.error('Error loading filter lists:', error);
        includeList = [];
        excludeList = [];
        filterApps = false;
        filterWindowTitle = false;
    }
}



ipcMain.handle('trigger-print', async (event) => {
    if (mainWindow && !mainWindow.isDestroyed()) {
        try {
            // Tell the dashboard window to start its printing process
            mainWindow.webContents.send('start-printing-view');
            return { success: true };
        } catch (error) {
            console.error("Failed to trigger print:", error);
            return { success: false };
        }
    }
    return { success: false, message: "Dashboard window not found." };
});



const SETTINGS_FILE = path.join(app.getPath('userData'), 'settings.json');
function loadSettings() {
    try {
        if (fs.existsSync(SETTINGS_FILE)) {
            const settings = JSON.parse(fs.readFileSync(SETTINGS_FILE));
            includeList = settings.includeList || [];
            excludeList = settings.excludeList || [];
        }
    } catch (error) {
        console.error('Error loading settings:', error);
    }
}

function saveSettings() {
  try {
      const settings = { includeList, excludeList };
      fs.writeFileSync(SETTINGS_FILE, JSON.stringify(settings, null, 2));
  } catch (error) {
      console.error('Error saving settings:', error);
  }
}

function loadSessionCounter() {
    try {
        if (fs.existsSync(SESSION_COUNTER_FILE)) {
            const data = JSON.parse(fs.readFileSync(SESSION_COUNTER_FILE));
            sessionCounter = data.counter || 1;
        }
    } catch (error) {
        console.error('Error loading session counter:', error);
        sessionCounter = 1;
    }
}

ipcMain.handle('print-request', async (event, action) => {
    console.log(`Routing print request from controls dropdown. Action: ${action}`);

    // --- LOGIC FOR 'Print Last Session' ---
    if (action === 'last') {
        try {
            // Find the most recent session file
            const sessionFiles = fs.readdirSync(SESSIONS_DIR).filter(file => file.endsWith('.json'));
            if (sessionFiles.length === 0) {
                console.log('No sessions found to print.');
                new Notification({ title: 'Print Failed', body: 'No saved sessions were found.' }).show();
                return { success: false, message: 'No saved sessions were found.' };
            }

            sessionFiles.sort((a, b) => {
                const timeA = parseInt(a.split('_').pop().replace('.json', ''), 10);
                const timeB = parseInt(b.split('_').pop().replace('.json', ''), 10);
                return timeB - timeA; // Sort descending to get the latest
            });

            const lastSessionId = sessionFiles[0];
            console.log(`Located last session to print: ${lastSessionId}`);

            // Ensure dashboard window is open
            if (!mainWindow || mainWindow.isDestroyed()) {
                createMainWindow();
                await new Promise(resolve => mainWindow.webContents.once('did-finish-load', resolve));
            }

            // Load session data and send it to the dashboard for printing
            const sessionFilePath = path.join(SESSIONS_DIR, lastSessionId);
            const sessionDataToPrint = JSON.parse(fs.readFileSync(sessionFilePath));

            mainWindow.show();
            mainWindow.webContents.send('generate-report', sessionDataToPrint);
            
            // Wait for dashboard to confirm it has rendered the report
            await new Promise(resolve => ipcMain.once('report-ready-for-pdf', resolve));

            // Tell the dashboard to trigger the print dialog
            mainWindow.webContents.send('trigger-pdf-generation');
            return { success: true };

        } catch (error) {
            console.error('Error handling "print last" action:', error);
            return { success: false, message: 'Failed to print the last session.' };
        }
    }

    // --- LOGIC FOR 'Choose Session' ---
    if (action === 'choose') {
        try {
            // Simply show the dashboard window, which already lists all sessions
            if (!mainWindow || mainWindow.isDestroyed()) {
                createMainWindow();
            }
            mainWindow.show();
            mainWindow.focus(); // Bring window to the front
            return { success: true, message: 'Dashboard shown for session selection.' };
        } catch (error) {
            console.error('Error handling "choose session" action:', error);
            return { success: false, message: 'Could not show dashboard.' };
        }
    }

    // Fallback for any unknown action
    console.warn(`Unknown print-request action received: ${action}`);
    return { success: false, message: `Unknown action: ${action}` };
});

// This handler generates and prints a summary of apps with actual text activity.
ipcMain.handle('print-text-app-summary', async () => {
    console.log('Generating filtered app summary report for printing...');
    try {
        // Ensure the dashboard window exists to display the report.
        if (!mainWindow || mainWindow.isDestroyed()) {
            createMainWindow();
            await new Promise(resolve => mainWindow.webContents.once('did-finish-load', resolve));
        }

        const allSessionFiles = fs.readdirSync(SESSIONS_DIR).filter(file => file.endsWith('.json'));
        if (allSessionFiles.length === 0) {
            new Notification({ title: 'No Data', body: 'There are no saved sessions to generate a report from.' }).show();
            return { success: false, message: 'No sessions found.' };
        }

        // Object to hold the summary data for apps with text.
        const appTextSummary = {};

        // Process every session file to gather data.
        allSessionFiles.forEach(file => {
            const sessionData = JSON.parse(fs.readFileSync(path.join(SESSIONS_DIR, file)));
            if (!sessionData || !sessionData.activities) return;

            sessionData.activities.forEach(activity => {
                // We only care about activities with text content.
                if (activity.type === 'keystroke' || activity.type === 'paste') {
                    const appName = activity.appName || 'Unknown';
                    
                    // If this is the first time we see this app, initialize it.
                    if (!appTextSummary[appName]) {
                        appTextSummary[appName] = {
                            name: appName,
                            keystrokes: 0,
                            pastes: 0,
                            characters: 0,
                        };
                    }

                    // Increment counters based on activity type.
                    if (activity.type === 'keystroke') {
                        appTextSummary[appName].keystrokes++;
                        appTextSummary[appName].characters++;
                    } else if (activity.type === 'paste' && activity.text) {
                        appTextSummary[appName].pastes++;
                        appTextSummary[appName].characters += activity.text.length;
                    }
                }
            });
        });

        // Convert the summary object to an array and filter out apps with NO text activity.
        const filteredReportData = Object.values(appTextSummary).filter(app => app.keystrokes > 0 || app.pastes > 0);
        
        // Sort the final list by the number of characters, descending.
        filteredReportData.sort((a, b) => b.characters - a.characters);

        if (filteredReportData.length === 0) {
             new Notification({ title: 'No Text Activity', body: 'No sessions contain any recorded keystrokes or pastes.' }).show();
             return { success: false, message: 'No text activity found to report.' };
        }

        // Send the final, filtered data to dashboard.html to be displayed for printing.
        mainWindow.show();
        mainWindow.webContents.send('generate-filtered-app-report', filteredReportData);

        // Wait for the dashboard to confirm it's ready for printing.
        await new Promise(resolve => ipcMain.once('report-ready-for-pdf', resolve));

        // Send the final command to trigger the print dialog.
        mainWindow.webContents.send('trigger-pdf-generation');
        return { success: true };

    } catch (error) {
        console.error('Error in print-text-app-summary handler:', error);
        return { success: false, message: 'Failed to generate the application summary report.' };
    }
});




function saveSessionCounter() {
    try {
        fs.writeFileSync(SESSION_COUNTER_FILE, JSON.stringify({ counter: sessionCounter }, null, 2));
    } catch (error) {
        console.error('Error saving session counter:', error);
    }
}


function createMainWindow() {
  mainWindow = new BrowserWindow({ 
      width: 1600, 
      height: 1000, 
      webPreferences: { 
          nodeIntegration: true, 
          contextIsolation: false 
      } 
  });
  mainWindow.loadFile('dashboard.html');
  mainWindow.on('closed', () => { mainWindow = null; });
}





function createControlWindow() {
  const { width } = screen.getPrimaryDisplay().workAreaSize;
  
  controlWindow = new BrowserWindow({
      width: 300,
      height: 120,
      x: width - 320,
      y: 20,
      frame: false,
      alwaysOnTop: true,
      skipTaskbar: true,
      resizable: false,
      webPreferences: {
          nodeIntegration: true,
          contextIsolation: false
      }
  });

  controlWindow.loadFile('controls.html');
  controlWindow.setVisibleOnAllWorkspaces(true);
}


async function startTracking() {
    if (isTracking) return;
    loadFilterLists(); 

    isTracking = true;
    currentSessionActivities = []; 

    // Generate session ID with sequential number
    const timestamp = Date.now();
    sessionID = `session_${sessionCounter}_${timestamp}`;
    
    console.log(`🎯 Starting Session #${sessionCounter} at ${new Date().toLocaleString()}`);
    console.log(`📋 Session ID: ${sessionID}`);
    
    startTime = new Date();
    sessionData = {
        sessionID: sessionID,
        sessionNumber: sessionCounter,
        startTime: startTime,
        endTime: null,
        activities: [],
        apps: {}
    };

    // Initialize keyboard listener
    keyListener = new GlobalKeyboardListener();
    
    keyListener.addListener(async (e, down) => {
        if (!isTracking || e.state !== 'DOWN') return;
        
        const context = await getCurrentContext();
        
        // Check for Paste (Ctrl+V)
        if (e.name === 'V' && (down['LEFT CTRL'] || down['RIGHT CTRL'])) {
            const pastedText = clipboard.readText();
            
            if (pastedText) {
                captureActivity('paste', {
                    text: pastedText,
                    timestamp: new Date(),
                    sessionID: sessionID,
                    sessionNumber: sessionCounter,
                    ...context
                });
            }
            return;
        }
        
        // Record other keystrokes with session info
        if (e.name) {
            captureActivity('keystroke', { 
                key: e.name, 
                sessionID: sessionID,
                sessionNumber: sessionCounter,
                ...context 
            });
        }
    });

    // Start mouse tracking for this session
    startMouseTracking();
    
    console.log(`✅ Session #${sessionCounter} tracking started successfully`);
}

function stopTracking() {
    if (!isTracking) return;
    
    isTracking = false;
    
    sessionData.endTime = new Date();
    const duration = sessionData.endTime - sessionData.startTime;
    
    console.log(`🛑 Stopping Session #${sessionCounter}`);
    console.log(`📊 Total Activities: ${currentSessionActivities.length}`);
    
    if (keyListener) {
        keyListener.kill();
        keyListener = null;
    }

    // Process and save session data
    if (currentSessionActivities.length > 0) {
        // Group activities by BOTH app name AND window title (not just app name)
        const sessionApps = {};
        
        currentSessionActivities.forEach(activity => {
            const appName = activity.appName || 'Unknown';
            const windowTitle = activity.windowTitle || 'Unknown';
            
            // Create unique key combining app name and window title
            const uniqueKey = `${appName}|||${windowTitle}`;
            
            if (!sessionApps[uniqueKey]) {
                sessionApps[uniqueKey] = {
                    appName: appName,
                    windowTitle: windowTitle,
                    displayName: `${appName} - ${windowTitle}`, // For display purposes
                    activities: [],
                    firstSeen: activity.timestamp,
                    lastSeen: activity.timestamp,
                    totalActivities: 0,
                    keystrokes: 0,
                    pastes: 0,
                    mouseEvents: 0,
                    totalCharacters: 0
                };
            }
            
            sessionApps[uniqueKey].activities.push(activity);
            sessionApps[uniqueKey].lastSeen = activity.timestamp;
            sessionApps[uniqueKey].totalActivities++;
            
            // Count different activity types
            if (activity.type === 'keystroke') {
                sessionApps[uniqueKey].keystrokes++;
                if (activity.key && activity.key.length === 1) {
                    sessionApps[uniqueKey].totalCharacters++;
                }
            } else if (activity.type === 'paste') {
                sessionApps[uniqueKey].pastes++;
                sessionApps[uniqueKey].totalCharacters += (activity.text?.length || 0);
            } else if (activity.type === 'mouse') {
                sessionApps[uniqueKey].mouseEvents++;
            }
        });

        console.log(`📱 Unique App/Window combinations in Session #${sessionCounter}:`);
        Object.keys(sessionApps).forEach(key => {
            const app = sessionApps[key];
            console.log(`   -> ${app.displayName} (${app.totalActivities} activities, ${app.totalCharacters} chars)`);
        });

        const completeSessionData = {
            sessionID: sessionID,
            sessionNumber: sessionCounter,
            startTime: sessionData.startTime.toISOString(),
            endTime: sessionData.endTime.toISOString(),
            duration: duration,
            totalActivities: currentSessionActivities.length,
            activities: currentSessionActivities,
            apps: sessionApps, // This now contains separate entries for each app+window combination
            mainContext: {
                appName: Object.values(sessionApps).sort((a,b) => b.totalActivities - a.totalActivities)[0]?.appName || 'Unknown',
                windowTitle: Object.values(sessionApps).sort((a,b) => b.totalActivities - a.totalActivities)[0]?.windowTitle || 'Unknown',
                url: currentSessionActivities[0]?.url || 'N/A'
            }
        };
        
        saveSessionCounter();
        const filename = `session_${sessionCounter}_${Date.now()}.json`;
        fs.writeFile(path.join(SESSIONS_DIR, filename), JSON.stringify(completeSessionData, null, 2), (err) => { 
            if (err) console.error('Error saving session:', err); 
        });
        console.log(`💾 Session #${sessionCounter} saved as: ${filename}`);

        sessionCounter++;
        saveSessionCounter();

        if (mainWindow && !mainWindow.isDestroyed()) {
            mainWindow.webContents.send('new-session-saved');
            mainWindow.show();
        }
    }

    // Clear current session data
    currentSessionActivities = [];
    sessionID = null;
    
    console.log(`✅ Session #${sessionCounter - 1} completed and saved successfully`);
    console.log(`🔄 Ready for Session #${sessionCounter}`);
}




async function getCurrentContext() {
  try {
      const activeWindow = await activeWin();
      console.log('activeWindow :>> ', activeWindow);
      return { windowTitle: activeWindow?.title || '?', appName: activeWindow?.owner?.name || '?', url: activeWindow?.url || 'N/A' };

    } 
    
    catch (error) { 

    return { windowTitle: '?', appName: '?', url: 'N/A' }; }

}

ipcMain.handle('print-specific-app', async (event, { appName, windowTitle, sessionId }) => {
    try {
        const sessionData = JSON.parse(fs.readFileSync(path.join(SESSIONS_DIR, sessionId)));
        
        // Filter for exact app + window title match
        const filteredActivities = sessionData.activities.filter(act => 
            act.appName === appName && act.windowTitle === windowTitle
        );
        
        console.log(`Printing specific: App="${appName}", Window="${windowTitle}"`);
        console.log(`Found ${filteredActivities.length} activities for this combination`);
        
        // Check if there's printable content
        const hasContent = filteredActivities.some(act => 
            act.type === 'keystroke' || act.type === 'paste'
        );
        
        if (!hasContent) {
            return { success: false, message: 'No text content found for this app/window combination' };
        }
        
        // Create isolated report data for this specific app+window
        const isolatedReportData = {
            sessionID: `${sessionData.sessionID}_${appName.replace(/\s+/g, '_')}_${windowTitle.replace(/\s+/g, '_')}`,
            sessionNumber: sessionData.sessionNumber,
            startTime: sessionData.startTime,
            endTime: sessionData.endTime,
            duration: sessionData.duration,
            activities: filteredActivities,
            totalActivities: filteredActivities.length,
            reportType: 'isolated', // Flag to indicate this is an isolated report
            targetApp: appName,
            targetWindow: windowTitle,
            apps: {
                [`${appName}|||${windowTitle}`]: {
                    appName: appName,
                    windowTitle: windowTitle,
                    displayName: `${appName} - ${windowTitle}`,
                    activities: filteredActivities,
                    totalActivities: filteredActivities.length,
                    firstSeen: filteredActivities[0]?.timestamp,
                    lastSeen: filteredActivities[filteredActivities.length - 1]?.timestamp
                }
            }
        };
        
        if (!mainWindow || mainWindow.isDestroyed()) {
            createMainWindow();
            await new Promise(resolve => mainWindow.webContents.once('did-finish-load', resolve));
        }
        
        mainWindow.show();
        mainWindow.webContents.send('generate-report', isolatedReportData);
        
        await new Promise(resolve => ipcMain.once('report-ready-for-pdf', resolve));
        mainWindow.webContents.send('trigger-pdf-generation');

        return { success: true };
    } catch (error) {
        console.error('Error in print-specific-app:', error);
        return { success: false, message: 'Failed to print app report.' };
    }
});


// ipcMain.handle('print-individual-app', async (event, { appName, appTitle, sessionId, sessionNumber }) => {
//     try {
//         const sessionData = JSON.parse(fs.readFileSync(path.join(SESSIONS_DIR, sessionId)));
        
//         // Filter for specific app activities
//         const appActivities = sessionData.activities.filter(act => 
//             act.appName === appName && act.windowTitle === appTitle
//         );
        
//         // Only get text-based activities
//         const textActivities = appActivities.filter(act => 
//             act.type === 'keystroke' || act.type === 'paste'
//         );
        
//         console.log(`App: ${appName}, Total: ${appActivities.length}, Text: ${textActivities.length}`);
        
//         if (textActivities.length === 0) {
//             return { success: false, message: `${appName} has no text content (only ${appActivities.length} mouse movements)` };
//         }
        
//         // Use ALL activities (including mouse) but ensure text exists
//         const appOnlyData = {
//             sessionID: sessionData.sessionID + '_' + appName.replace(/\s+/g, '_'),
//             sessionNumber: sessionNumber,
//             startTime: sessionData.startTime,
//             endTime: sessionData.endTime,
//             activities: appActivities, // Include all activities for this app
//             totalActivities: appActivities.length,
//             apps: {
//                 [appName]: {
//                     name: appName,
//                     activities: appActivities,
//                     totalActivities: appActivities.length,
//                     firstSeen: appActivities[0]?.timestamp,
//                     lastSeen: appActivities[appActivities.length - 1]?.timestamp
//                 }
//             }
//         };
        
//         if (!mainWindow || mainWindow.isDestroyed()) {
//             createMainWindow();
//             await new Promise(resolve => mainWindow.webContents.once('did-finish-load', resolve));
//         }
        
//         mainWindow.show();
//         mainWindow.webContents.send('generate-report', appOnlyData);
        
//         await new Promise(resolve => ipcMain.once('report-ready-for-pdf', resolve));
//         mainWindow.webContents.send('trigger-pdf-generation');

//         return { success: true };
//     } catch (error) {
//         console.error('Error printing individual app:', error);
//         return { success: false, message: 'Failed to print app report.' };
//     }
// });


ipcMain.handle('print-last-session', async () => {
    try {
        // 1. Get all session files from the sessions directory.
        const sessionFiles = fs.readdirSync(SESSIONS_DIR)
                               .filter(file => file.endsWith('.json'));

        // 2. Check if there are any sessions available to print.
        if (sessionFiles.length === 0) {
            console.log('No sessions found to print.');
            // You can optionally show an error dialog to the user here.
            return { success: false, message: 'No saved sessions were found.' };
        }

        // 3. Sort the files to find the most recent one.
        // This sort function correctly parses the timestamp from filenames like 'session_1_1754137905613.json'.
        sessionFiles.sort((a, b) => {
            const timeA = parseInt(a.split('_').pop().replace('.json', ''), 10);
            const timeB = parseInt(b.split('_').pop().replace('.json', ''), 10);
            return timeB - timeA; // Sort in descending order to get the latest session first.
        });

        // 4. The most recent session is the first file in the sorted array.
        const lastSessionId = sessionFiles[0];
        console.log(`Located last session to print: ${lastSessionId}`);

        // 5. Now, reuse your existing print logic from the 'print-session' handler.
        if (!mainWindow || mainWindow.isDestroyed()) {
            console.log('Dashboard window not found, creating it for printing...');
            createMainWindow();
            // Wait for the new window to fully load its content.
            await new Promise(resolve => mainWindow.webContents.once('did-finish-load', resolve));
            console.log('Dashboard window is ready for printing.');
        }

        const sessionFilePath = path.join(SESSIONS_DIR, lastSessionId);
        const sessionDataToPrint = JSON.parse(fs.readFileSync(sessionFilePath));

        // Make sure the dashboard window is visible.
        mainWindow.show();
        
        // Send the specific session data to the dashboard to be rendered for printing.
        mainWindow.webContents.send('generate-report', sessionDataToPrint);
        
        // Wait for the dashboard to confirm that the report is rendered and ready.
        await new Promise(resolve => ipcMain.once('report-ready-for-pdf', resolve));

        // Tell the dashboard to trigger the final PDF generation/print dialog.
        mainWindow.webContents.send('trigger-pdf-generation');

        return { success: true };

    } catch (error) {
        console.error('Error in print-last-session handler:', error);
        return { success: false, message: 'An error occurred while trying to print the last session.' };
    }
});

ipcMain.handle('print-app-list', async () => {
    try {
        // Step 1: Make sure the dashboard window exists to display the report.
        if (!mainWindow || mainWindow.isDestroyed()) {
            createMainWindow();
            await new Promise(resolve => mainWindow.webContents.once('did-finish-load', resolve));
        }

        // Step 2: Read all session files from the disk.
        const allSessionFiles = fs.readdirSync(SESSIONS_DIR).filter(file => file.endsWith('.json'));
        if (allSessionFiles.length === 0) {
            new Notification({ title: 'No Data', body: 'There are no saved sessions to generate an app report.' }).show();
            return { success: false, message: 'No sessions found.' };
        }

        // Step 3: Process the files to summarize app usage.
        const appSummary = {};
        allSessionFiles.forEach(file => {
            const sessionData = JSON.parse(fs.readFileSync(path.join(SESSIONS_DIR, file)));
            if (sessionData && sessionData.apps) {
                for (const appName in sessionData.apps) {
                    const app = sessionData.apps[appName];
                    if (!appSummary[appName]) {
                        appSummary[appName] = { name: appName, totalActivities: 0, totalTimeSpent: 0, sessionCount: 0 };
                    }
                    appSummary[appName].totalActivities += app.totalActivities || 0;
                    appSummary[appName].sessionCount++;
                    if (app.activities && app.activities.length > 1) {
                        const appStartTime = new Date(app.activities[0].timestamp);
                        const appEndTime = new Date(app.activities[app.activities.length - 1].timestamp);
                        appSummary[appName].totalTimeSpent += (appEndTime - appStartTime);
                    }
                }
            }
        });

        const sortedAppSummary = Object.values(appSummary).sort((a, b) => b.totalActivities - a.totalActivities);

        // Step 4: Send the final, calculated data to dashboard.html to be displayed.
        mainWindow.show();
        mainWindow.webContents.send('generate-app-summary-report', sortedAppSummary);

        // Step 5: Wait for the dashboard to confirm it's ready for printing.
        await new Promise(resolve => ipcMain.once('report-ready-for-pdf', resolve));

        // Step 6: Send the final command to trigger the print dialog on the dashboard window.
        mainWindow.webContents.send('trigger-pdf-generation');
        return { success: true };

    } catch (error) {
        console.error('Error in print-app-list handler:', error);
        return { success: false, message: 'Failed to generate the application summary report.' };
    }
});

ipcMain.handle('print-choose-session', async () => {
    try {
        if (!mainWindow || mainWindow.isDestroyed()) {
            createMainWindow();
        }
        mainWindow.show();
        mainWindow.focus(); // Bring the window to the front
        return { success: true, message: 'Dashboard shown for session selection.' };
    } catch (error) {
        console.error('Error showing dashboard for session selection:', error);
        return { success: false, message: 'Could not show dashboard.' };
    }
});

function captureActivity(type, data) {
    if (!isTracking || !sessionID) return;

    const appName = (data.appName || 'unknown').toLowerCase();
    const windowTitle = (data.windowTitle || 'unknown').toLowerCase();

    console.log(`\n--- [ACTIVITY FILTER CHECK] ---`);
    console.log(`App: "${appName}", Window: "${windowTitle}"`);
    console.log(`Filter Apps: ${filterApps}, Filter Window Titles: ${filterWindowTitle}`);

    // Determine what text to search in based on flags
    let searchContext = '';
    if (filterApps && filterWindowTitle) {
        searchContext = `${appName} ${windowTitle}`;
        console.log(`Checking both app and window title: "${searchContext}"`);
    } else if (filterApps) {
        searchContext = appName;
        console.log(`Checking app name only: "${searchContext}"`);
    } else if (filterWindowTitle) {
        searchContext = windowTitle;
        console.log(`Checking window title only: "${searchContext}"`);
    } else {
        // If no filtering flags are set, track everything
        console.log(`No filtering enabled - tracking all activities`);
    }

    // Only apply filtering if at least one flag is enabled
    if (filterApps || filterWindowTitle) {
        // Priority 1: Include List (whitelist mode)
        if (includeList.length > 0) {
            const isIncluded = includeList.some(keyword => {
                const match = searchContext.includes(keyword);
                if (match) console.log(`✓ Found include keyword: "${keyword}"`);
                return match;
            });
            
            if (!isIncluded) {
                console.log(`❌ FILTERED OUT: Not in include list`);
                console.log(`-----------------------------`);
                return; // Don't track this activity
            }
            console.log(`✅ INCLUDED: Found in include list`);
        }
        // Priority 2: Exclude List (blacklist mode) - only if include list is empty
        else if (excludeList.length > 0) {
            const isExcluded = excludeList.some(keyword => {
                const match = searchContext.includes(keyword);
                if (match) console.log(`✗ Found exclude keyword: "${keyword}"`);
                return match;
            });
            
            if (isExcluded) {
                console.log(`❌ FILTERED OUT: Found in exclude list`);
                console.log(`-----------------------------`);
                return; // Don't track this activity
            }
            console.log(`✅ ALLOWED: Not in exclude list`);
        }
    }

    console.log(`✅ TRACKING: Activity will be recorded`);
    console.log(`-----------------------------`);

    // Create activity object
    const activity = {
        id: Date.now() + Math.random(),
        type,
        timestamp: new Date().toISOString(),
        sessionID: sessionID,
        sessionNumber: sessionCounter,
        ...data
    };

    if (type === 'keystroke') {
        console.log(`⌨️ Session #${sessionCounter} | ${activity.appName} | Key: ${activity.key}`);
    } else if (type === 'paste') {
        console.log(`📋 Session #${sessionCounter} | ${activity.appName} | Paste: ${activity.text?.substring(0, 50)}...`);
    }

    // Store the activity
    trackingData.push(activity);
    if (sessionData) {
        sessionData.activities.push(activity);
    }
    currentSessionActivities.push(activity);
    
    // Update dashboard if open
    if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.webContents.send('activity-update', activity);
    }
}

// IPC handlers for filter management
ipcMain.handle('get-filter-config', () => {
    return {
        filterApps,
        filterWindowTitle,
        includeList,
        excludeList
    };
});


ipcMain.handle('update-filter-config', (event, config) => {
    try {
        filterApps = config.filterApps;
        filterWindowTitle = config.filterWindowTitle;
        
        // Save to root directory instead of userData
        const configFilePath = path.join(__dirname, 'filter_config.json');
        fs.writeFileSync(configFilePath, JSON.stringify({
            filterApps,
            filterWindowTitle
        }, null, 2));
        
        console.log('Filter configuration updated:', { filterApps, filterWindowTitle });
        return { success: true };
    } catch (error) {
        console.error('Error updating filter config:', error);
        return { success: false };
    }
});

ipcMain.handle('reload-filters', () => {
    loadFilterLists();
    return { success: true };
});

function startMouseTracking() {
    const trackMouse = async () => {
        if (!isTracking || !sessionID) return;
        
        const mousePos = screen.getCursorScreenPoint();
        const context = await getCurrentContext();
        console.log('context :>> ', context);
        captureActivity('mouse', {
            x: mousePos.x,
            y: mousePos.y,
            timestamp: new Date(),
            sessionID: sessionID,
            sessionNumber: sessionCounter,
            ...context
        });
        
        setTimeout(trackMouse, 100);
    };
    
    trackMouse();
}

ipcMain.handle('get-all-sessions', () => {
    const sessionFiles = fs.readdirSync(SESSIONS_DIR).filter(file => file.endsWith('.json'));
    
    return sessionFiles.map(file => {
        try {
            const data = JSON.parse(fs.readFileSync(path.join(SESSIONS_DIR, file)));
            
            // Convert the apps object to an array with separate entries
            const appsArray = Object.values(data.apps || {}).map(app => ({
                appName: app.appName,
                windowTitle: app.windowTitle,
                displayName: app.displayName || `${app.appName} - ${app.windowTitle}`,
                totalActivities: app.totalActivities,
                keystrokes: app.keystrokes || 0,
                pastes: app.pastes || 0,
                totalCharacters: app.totalCharacters || 0,
                firstSeen: app.firstSeen,
                lastSeen: app.lastSeen
            }));
            
            return {
                id: file,
                sessionNumber: data.sessionNumber || 'Unknown',
                sessionID: data.sessionID,
                startTime: data.startTime,
                endTime: data.endTime,
                duration: data.duration,
                totalActivities: data.totalActivities,
                apps: appsArray, // Now an array of separate app+window combinations
                mainContext: data.mainContext
            };
        } catch { 
            return null; 
        }
    }).filter(s => s).sort((a, b) => (b.sessionNumber || 0) - (a.sessionNumber || 0));
});

ipcMain.handle('delete-all-sessions', () => {
    try {
        fs.readdirSync(SESSIONS_DIR).forEach(file => fs.unlinkSync(path.join(SESSIONS_DIR, file)));

        sessionCounter = 1;
        saveSessionCounter();

      // Tell dashboard to refresh its (now empty) list
      if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.webContents.send('new-session-saved'); 
      }
      return { success: true };
    } catch (error) { console.error('Failed to delete sessions:', error); return { success: false }; }
  });

  

  ipcMain.handle('search-all-data', async (event, searchTerm) => {
    if (!searchTerm || searchTerm.trim() === '') {
        return [];
    }

    const matchingSessionIds = new Set();
    const lowerCaseSearchTerm = searchTerm.toLowerCase();

    try {
        const sessionFiles = fs.readdirSync(SESSIONS_DIR).filter(file => file.endsWith('.json'));

        for (const file of sessionFiles) {
            const filePath = path.join(SESSIONS_DIR, file);
            const sessionData = JSON.parse(fs.readFileSync(filePath, 'utf-8'));

            if (!sessionData || !Array.isArray(sessionData.activities)) {
                continue;
            }

            let fullTextContent = '';
            let metadataMatch = false;

            // This loop checks metadata and builds a single string of all typed/pasted content
            for (const activity of sessionData.activities) {
                // Check for match in app name or window title
                if ((activity.appName && activity.appName.toLowerCase().includes(lowerCaseSearchTerm)) ||
                    (activity.windowTitle && activity.windowTitle.toLowerCase().includes(lowerCaseSearchTerm))) {
                    metadataMatch = true;
                }

                // Build the full text string
                if (activity.type === 'paste' && activity.text) {
                    fullTextContent += activity.text + ' ';
                } else if (activity.type === 'keystroke' && activity.key) {
                    if (activity.key.length === 1) {
                        fullTextContent += activity.key;
                    } else if (activity.key === 'SPACE') {
                        fullTextContent += ' ';
                    }
                }
            }
            const contentMatch = fullTextContent.toLowerCase().includes(lowerCaseSearchTerm);
            if (metadataMatch || contentMatch) {
                matchingSessionIds.add(file);
            }
        }
    } catch (error)
    {
        console.error('Error during file search:', error);
        return [];
    }

    return Array.from(matchingSessionIds);
});

ipcMain.handle('get-session-app-breakdown', (event, sessionId) => {
    try {
        const sessionData = JSON.parse(fs.readFileSync(path.join(SESSIONS_DIR, sessionId)));
        
        // Group activities by app + window title combination
        const appWindowBreakdown = {};
        
        sessionData.activities.forEach(activity => {
            const appName = activity.appName || 'Unknown';
            const windowTitle = activity.windowTitle || 'Unknown';
            const combinedKey = `${appName}|||${windowTitle}`; // Use special separator
            
            if (!appWindowBreakdown[combinedKey]) {
                appWindowBreakdown[combinedKey] = {
                    appName: appName,
                    windowTitle: windowTitle,
                    activities: [],
                    keystrokes: 0,
                    pastes: 0,
                    mouseClicks: 0,
                    totalCharacters: 0,
                    firstSeen: activity.timestamp,
                    lastSeen: activity.timestamp
                };
            }
            
            appWindowBreakdown[combinedKey].activities.push(activity);
            appWindowBreakdown[combinedKey].lastSeen = activity.timestamp;
            
            // Count different activity types
            if (activity.type === 'keystroke') {
                appWindowBreakdown[combinedKey].keystrokes++;
                if (activity.key && activity.key.length === 1) {
                    appWindowBreakdown[combinedKey].totalCharacters++;
                }
            } else if (activity.type === 'paste') {
                appWindowBreakdown[combinedKey].pastes++;
                appWindowBreakdown[combinedKey].totalCharacters += (activity.text?.length || 0);
            } else if (activity.type === 'mouse') {
                appWindowBreakdown[combinedKey].mouseClicks++;
            }
        });
        
        // Convert to array and sort by total characters (most productive first)
        const breakdown = Object.values(appWindowBreakdown)
            .filter(item => item.keystrokes > 0 || item.pastes > 0) // Only include items with text activity
            .sort((a, b) => b.totalCharacters - a.totalCharacters);
            
        console.log(`Session breakdown: ${breakdown.length} unique app/window combinations with text activity`);
        
        return breakdown;
    } catch (error) {
        console.error('Error getting session app breakdown:', error);
        return [];
    }
});
  ipcMain.handle('get-session-details', (event, sessionId) => {
    try {
        console.log('Looking for session file:', sessionId);
        const filePath = path.join(SESSIONS_DIR, sessionId);
        
        if (!fs.existsSync(filePath)) {
            console.log('File does not exist:', filePath);
            return null;
        }
        
        const data = fs.readFileSync(filePath, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        console.error('Error reading session file:', error);
        return null;
    }
});

function saveSessionData() {
    const filename = `session_${Date.now()}.json`;
    const filepath = path.join(DATA_DIR, filename);
    
    fs.writeFileSync(filepath, JSON.stringify(sessionData, null, 2));
}


function formatDuration(milliseconds) {
    if (!milliseconds || milliseconds < 0) return '0s';
    
    const seconds = Math.floor(milliseconds / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    
    if (hours > 0) {
        return `${hours}h ${minutes % 60}m ${seconds % 60}s`;
    } else if (minutes > 0) {
        return `${minutes}m ${seconds % 60}s`;
    } else {
        return `${seconds}s`;
    }
}

function generateReport() {
    if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.webContents.send('generate-report', sessionData);
        if (!isInvisible) {
            mainWindow.show();
        }
    }
}

ipcMain.handle('start-tracking', async () => { // <-- Added 'async' here
    await startTracking();                     // <-- Added 'await' here
    return { success: true };
});


ipcMain.handle('stop-tracking', () => {
    stopTracking();
    return { success: true };
});

ipcMain.handle('toggle-invisible', (event, invisible) => {
    isInvisible = invisible;
    if (controlWindow) {
        if (invisible) {
            controlWindow.hide();
            new Notification({
                title: 'Tracker is Now Invisible',
                body: 'Press Ctrl+Shift+Alt+V to show the controls again.'
            }).show();
            // Auto-start tracking if not already running
            if (!isTracking) {
                startTracking();
            }
        } else {
            controlWindow.show();
        }
    }
    return { success: true };
});

ipcMain.handle('get-tracking-data', () => {
    return trackingData;
});


ipcMain.handle('get-text-for-app-window', (event, { sessionId, appName, windowTitle }) => {
    try {
        const sessionData = JSON.parse(fs.readFileSync(path.join(SESSIONS_DIR, sessionId)));
        
        // Filter activities for exact app + window match
        const relevantActivities = sessionData.activities.filter(act => 
            act.appName === appName && 
            act.windowTitle === windowTitle &&
            (act.type === 'keystroke' || act.type === 'paste')
        ).sort((a, b) => new Date(a.timestamp) - new Date(b.timestamp));
        
        // Reconstruct text content
        let reconstructedText = '';
        let textSegments = [];
        
        relevantActivities.forEach(activity => {
            if (activity.type === 'paste' && activity.text) {
                reconstructedText += activity.text;
                textSegments.push({
                    type: 'paste',
                    content: activity.text,
                    timestamp: activity.timestamp,
                    length: activity.text.length
                });
            } else if (activity.type === 'keystroke' && activity.key) {
                if (activity.key.length === 1) {
                    reconstructedText += activity.key;
                } else if (activity.key === 'SPACE') {
                    reconstructedText += ' ';
                } else if (activity.key === 'ENTER') {
                    reconstructedText += '\n';
                } else if (activity.key === 'TAB') {
                    reconstructedText += '\t';
                } else if (activity.key === 'BACKSPACE' && reconstructedText.length > 0) {
                    reconstructedText = reconstructedText.slice(0, -1);
                }
                
                textSegments.push({
                    type: 'keystroke',
                    content: activity.key,
                    timestamp: activity.timestamp
                });
            }
        });
        
        return {
            appName,
            windowTitle,
            reconstructedText,
            textSegments,
            totalTextActivities: relevantActivities.length,
            totalCharacters: reconstructedText.length,
            wordCount: reconstructedText.split(/\s+/).filter(word => word.length > 0).length
        };
        
    } catch (error) {
        console.error('Error getting text for app+window:', error);
        return null;
    }
});

ipcMain.handle('get-text-content', (event, { sessionId, appName, windowTitle }) => {
    try {
        const sessionData = JSON.parse(fs.readFileSync(path.join(SESSIONS_DIR, sessionId)));
        
        // Filter for specific app + window combination
        const relevantActivities = sessionData.activities.filter(act => 
            act.appName === appName && act.windowTitle === windowTitle &&
            (act.type === 'keystroke' || act.type === 'paste')
        ).sort((a, b) => new Date(a.timestamp) - new Date(b.timestamp));
        
        // Reconstruct the text content
        let reconstructedText = '';
        let textSegments = [];
        
        relevantActivities.forEach(activity => {
            if (activity.type === 'paste' && activity.text) {
                reconstructedText += activity.text;
                textSegments.push({
                    type: 'paste',
                    content: activity.text,
                    timestamp: activity.timestamp
                });
            } else if (activity.type === 'keystroke' && activity.key) {
                if (activity.key.length === 1) {
                    reconstructedText += activity.key;
                    textSegments.push({
                        type: 'keystroke',
                        content: activity.key,
                        timestamp: activity.timestamp
                    });
                } else if (activity.key === 'SPACE') {
                    reconstructedText += ' ';
                    textSegments.push({
                        type: 'keystroke',
                        content: ' ',
                        timestamp: activity.timestamp
                    });
                } else if (activity.key === 'ENTER') {
                    reconstructedText += '\n';
                    textSegments.push({
                        type: 'keystroke',
                        content: '\n',
                        timestamp: activity.timestamp
                    });
                }
                // Handle backspace by removing last character
                else if (activity.key === 'BACKSPACE' && reconstructedText.length > 0) {
                    reconstructedText = reconstructedText.slice(0, -1);
                    textSegments.push({
                        type: 'keystroke',
                        content: '[BACKSPACE]',
                        timestamp: activity.timestamp
                    });
                }
            }
        });
        
        return {
            appName,
            windowTitle,
            reconstructedText,
            textSegments,
            totalActivities: relevantActivities.length,
            totalCharacters: reconstructedText.length
        };
        
    } catch (error) {
        console.error('Error getting text content:', error);
        return null;
    }
});


ipcMain.handle('show-dashboard', () => {
  if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.show();
  } else {
      createMainWindow();
      mainWindow.show();
  }
  return { success: true };
});



// Add this IPC handler to main.js
ipcMain.handle('force-app-refresh', async () => {
    console.log('🔄 Force refresh requested...');
    
    try {
        // Clear all caches
        const windows = BrowserWindow.getAllWindows();
        for (const window of windows) {
            if (!window.isDestroyed()) {
                await window.webContents.session.clearCache();
                await window.webContents.session.clearStorageData();
            }
        }
        
        // Recreate control window with fresh theme
        if (controlWindow && !controlWindow.isDestroyed()) {
            controlWindow.close();
        }
        
        setTimeout(() => {
            createControlWindow();
        }, 500);
        
        return { success: true, version: app.getVersion() };
    } catch (error) {
        console.error('Error during force refresh:', error);
        return { success: false };
    }
});

// Add global shortcut for force refresh

app.whenReady().then(() => {
    console.log('🔢 App Version:', app.getVersion());
    console.log('📦 Package Version:', require('./package.json').version);

    loadFilterLists(); // <-- ADD THIS LINE

    loadSessionCounter(); // Load the counter first
    // MODIFIED LINE: Only create the window if the flag is false.
    if (isInvisible) {
        log.info('Starting in invisible mode. Tracking has begun.');

        // If starting in invisible mode, don't create any windows yet.
        // Immediately start the tracking process in the background.
        console.log('🚀 Starting in invisible mode. Tracking has begun.');
        startTracking();
    } else {
        // If starting in normal (visible) mode, create the control panel.
        createControlWindow();
    }
    autoUpdater.checkForUpdatesAndNotify();


    autoUpdater.on('checking-for-update', () => {
        sendUpdateMessage('Checking for update...');
      });
      
      autoUpdater.on('update-available', (info) => {
        sendUpdateMessage(`Update available: version ${info.version}. Starting download...`);
        // Now we manually trigger the download
        autoUpdater.downloadUpdate();
      });

      autoUpdater.on('update-not-available', (info) => {
        sendUpdateMessage('No new update available.');
      });
            
      autoUpdater.on('error', (err) => {
        sendUpdateMessage('Error in auto-updater: ' + err.toString());
      });
      
      globalShortcut.register('CommandOrControl+Shift+Alt+F', async () => {
        console.log('🔄 Force refresh shortcut pressed');
        await ipcRenderer.invoke('force-app-refresh');
    });
    
      autoUpdater.on('download-progress', (progressObj) => {
        let message = `Downloading: ${Math.round(progressObj.percent)}%`;
        sendUpdateMessage(message);
      });
      

      

 
    

      autoUpdater.on('update-downloaded', (info) => {
        sendUpdateMessage(`Update ${info.version} downloaded. Ready to install.`);
      
        if (isInvisible) {
          // INVISIBLE MODE: Show a system notification
          const notification = new Notification({
            title: 'Update Ready to Install',
            body: `Version ${info.version} is downloaded. Click here to restart and install.`
          });
          notification.on('click', () => {
            log.info('Notification clicked. Quitting and installing update silently.');
            // MODIFICATION: Add 'true' to install silently and restart the app
            autoUpdater.quitAndInstall(true, true); 
          });
          notification.show();
        } else {
          // VISIBLE MODE: Show a dialog box
          dialog.showMessageBox({
            type: 'info',
            title: 'Update Ready',
            message: `A new version (${info.version}) has been downloaded. Restart the application to apply the update?`,
            buttons: ['Restart', 'Later']
          }).then((buttonIndex) => {
            if (buttonIndex.response === 0) {
              // MODIFICATION: Add 'true' to install silently and restart the app
              autoUpdater.quitAndInstall(true, true);
            }
          });
        }
      });
    

    setInterval(() => {
        if (!app.isPackaged) return; // Don't check during development
        autoUpdater.checkForUpdatesAndNotify();
    }, 300000); 

    globalShortcut.register('CommandOrControl+Shift+Alt+R', () => {
        console.log('Force refresh shortcut pressed');
        if (controlWindow && !controlWindow.isDestroyed()) {
            controlWindow.webContents.session.clearCache();
            controlWindow.webContents.reload();
        }
    });

    ipcMain.handle('force-refresh-controls', () => {
        if (controlWindow && !controlWindow.isDestroyed()) {
            // Clear the window cache
            controlWindow.webContents.session.clearCache();
            
            // Force reload the controls window
            controlWindow.webContents.reload();
            
            // If that doesn't work, recreate the window entirely
            setTimeout(() => {
                if (controlWindow && !controlWindow.isDestroyed()) {
                    controlWindow.close();
                    createControlWindow();
                }
            }, 1000);
            
            return { success: true };
        }
        return { success: false };
    });
    
    
    
    // Make sure you still have the other listeners for logging!
    autoUpdater.on('error', (err) => {
    console.error('Error in auto-updater. ' + err);
    });


    // createMainWindow();
    globalShortcut.register('CommandOrControl+Shift+Alt+V', () => {
        console.log('Global shortcut pressed.');
    
        // SCENARIO 1: The app is in an active, invisible tracking session.
        if (isTracking && isInvisible) {
            console.log('✅ Stopping invisible tracking session and revealing dashboard.');
    
            // 1. Stop tracking and save the session data.
            stopTracking();
    
            // 2. Create the main dashboard window if it doesn't exist.
            if (!mainWindow || mainWindow.isDestroyed()) {
                createMainWindow();
            }
            // 3. Show and focus the dashboard.
            mainWindow.show();
            mainWindow.focus();
    
            // 4. Create the control window now that the app is visible.
            if (!controlWindow || controlWindow.isDestroyed()) {
                createControlWindow();
            }
            controlWindow.show();
    
            // 5. Officially exit "invisible mode".
            isInvisible = false;
    
        } else {
            console.log('Toggling control window visibility.');
            if (controlWindow && !controlWindow.isDestroyed()) {
                if (controlWindow.isVisible()) {
                    controlWindow.hide();
                } else {
                    controlWindow.show();
                }
            }
        }
    });

    app.on('activate', () => {
        if (BrowserWindow.getAllWindows().length === 0) {
            createMainWindow();
        }
    });



});

ipcMain.handle('print-separated-reports', async (event, sessionId) => {
    try {
        // Get the breakdown of all app/window combinations
        const breakdown = await new Promise(resolve => {
            ipcMain.handleOnce('get-session-app-breakdown', () => {
                const sessionData = JSON.parse(fs.readFileSync(path.join(SESSIONS_DIR, sessionId)));
                // ... (use the breakdown logic from above)
                resolve(breakdown);
            });
        });
        
        if (!mainWindow || mainWindow.isDestroyed()) {
            createMainWindow();
            await new Promise(resolve => mainWindow.webContents.once('did-finish-load', resolve));
        }
        
        // Send separated data for each app/window combination
        mainWindow.show();
        mainWindow.webContents.send('generate-separated-reports', {
            sessionId,
            breakdown
        });
        
        await new Promise(resolve => ipcMain.once('report-ready-for-pdf', resolve));
        mainWindow.webContents.send('trigger-pdf-generation');
        
        return { success: true };
    } catch (error) {
        console.error('Error generating separated reports:', error);
        return { success: false };
    }
});

ipcMain.handle('print-session', async (event, sessionId) => {
    if (!mainWindow || mainWindow.isDestroyed()) {
        console.log('Dashboard window not found, creating it for printing...');
        createMainWindow();
        // Wait for the new window to fully load its content
        await new Promise(resolve => mainWindow.webContents.once('did-finish-load', resolve));
        console.log('Dashboard window created and ready for printing.');
    }

    try {
        // Find the specific session file
        const sessionFilePath = path.join(SESSIONS_DIR, sessionId);
        if (!fs.existsSync(sessionFilePath)) {
             return { success: false, message: 'Session file not found.' };
        }
        
        const sessionDataToPrint = JSON.parse(fs.readFileSync(sessionFilePath));

        console.log(`Sending print command for session: ${sessionDataToPrint.sessionID}`);
        
        mainWindow.show(); // Make sure the window is visible
        
        // Send the data to the dashboard and wait for it to confirm it's ready
        mainWindow.webContents.send('generate-report', sessionDataToPrint);
        
        // Wait for the renderer to signal that the report is rendered
        await new Promise(resolve => ipcMain.once('report-ready-for-pdf', resolve));

        // Now, tell the dashboard to create the PDF/print
        mainWindow.webContents.send('trigger-pdf-generation');

        return { success: true };

    } catch (error) {
        console.error('Error in print-session handler:', error);
        return { success: false, message: 'Failed to process print command.' };
    }
});



app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') {
        app.quit();
    }
});

app.on('will-quit', () => {
    globalShortcut.unregisterAll();
    if (keyListener) {
        keyListener.kill();
    }
});

app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
        createMainWindow();
        createControlWindow();
    }
});